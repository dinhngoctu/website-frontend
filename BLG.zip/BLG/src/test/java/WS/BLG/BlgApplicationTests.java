package WS.BLG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlgApplicationTests {

	@Test
	void contextLoads() {
	}

}
