package WS.BLG;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlgApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlgApplication.class, args);
	}

}
