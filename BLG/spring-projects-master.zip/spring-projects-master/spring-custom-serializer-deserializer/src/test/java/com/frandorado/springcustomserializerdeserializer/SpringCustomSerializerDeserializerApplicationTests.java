package com.frandorado.springcustomserializerdeserializer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCustomSerializerDeserializerApplicationTests {

	@Test
	void contextLoads() {
	}

}
