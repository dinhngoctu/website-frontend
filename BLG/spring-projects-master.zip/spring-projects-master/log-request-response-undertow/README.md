# Log Request and Response with Undertow

Logging Request and Response in Spring with Undertow (without body). More info [here](https://frandorado.github.io/spring/2018/11/04/log-request-response-with-undertow-spring.html)