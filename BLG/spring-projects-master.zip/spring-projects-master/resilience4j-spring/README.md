# Circuit Breaker with Resilience4j and Spring

This project shows an example of use of Circuit Breaker pattern in Spring using Resilience4j. More info [here](https://frandorado.github.io/spring/2019/01/04/circuitbreaker-resilience4j-spring.html)
