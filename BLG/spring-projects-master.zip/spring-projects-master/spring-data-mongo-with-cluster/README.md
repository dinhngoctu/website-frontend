# Spring Data Mongo using Mongo Cluster

More info [here](https://frandorado.github.io/spring/2019/04/16/mongo-cluster-with-spring-data-mongo.html)