package io.github.frandorado.springuploads3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringUploadS3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
