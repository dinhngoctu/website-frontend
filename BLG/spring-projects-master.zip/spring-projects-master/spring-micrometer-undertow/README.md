# Spring Micrometer Undertow

Link to blog [Spring Actuator Undertow](https://frandorado.github.io/spring/2020/03/31/spring-actuator-undertow.html)


## How to test

```
mvn spring-boot:run
```
