(function() {
    'use strict';

    angular
        .module('ribbonCacheApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
