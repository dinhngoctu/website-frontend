/**
 * Cassandra specific configuration.
 */
package com.mycompany.myapp.config.cassandra;
