/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package com.mycompany.myapp.web.rest.dto;
